package Graphics;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import static java.awt.Color.green;
import static java.awt.Color.red;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

// Student class using encapsulation
class Student {
    private String name;
    private String regNumber;
    private int mathMarks;
    private int javaMarks;
    private int phpMarks;
    
    private static final String URL="jdbc:mariadb://localhost:3306/java";
    private static final String USERNAME="root";
    private static final String PASSWORD="";

    public Student(String name, String regNumber, int mathMarks, int javaMarks, int phpMarks) {
        this.name = name;
        this.regNumber = regNumber;
        this.mathMarks = mathMarks;
        this.javaMarks = javaMarks;
        this.phpMarks = phpMarks;
    }

    public String getName() {
        return name;
    }

    public String getRegNumber() {
        return regNumber;
    }

    public int getMathMarks() {
        return mathMarks;
    }

    public int getJavaMarks() {
        return javaMarks;
    }

    public int getPhpMarks() {
        return phpMarks;
    }

    public int getTotalMarks() {
        return mathMarks + javaMarks + phpMarks;
    }

    public double getAverageMarks() {
        return getTotalMarks() / 3.0;
    }
}

// Main class implementing the student management system
class StudentManagementSystem extends JFrame {
    private ArrayList<Student> students = new ArrayList<>();
    private JTextField nameField, regNumberField, mathMarksField, javaMarksField, phpMarksField;
    private JTable table;
    private DefaultTableModel tableModel;

    public StudentManagementSystem() {
        // Set up the frame
        setTitle("Student Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create components
        JPanel inputPanel = new JPanel(new GridLayout(8, 2));
        inputPanel.setBounds(90, 80, 100, 87);
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Reg Number:"));
        regNumberField = new JTextField();
        inputPanel.add(regNumberField);

        inputPanel.add(new JLabel("Mathematics Marks:"));
        mathMarksField = new JTextField();
        inputPanel.add(mathMarksField);

        inputPanel.add(new JLabel("Java Marks:"));
        javaMarksField = new JTextField();
        inputPanel.add(javaMarksField);

        inputPanel.add(new JLabel("PHP Marks:"));
        phpMarksField = new JTextField();
        inputPanel.add(phpMarksField);

        JButton addButton = new JButton("Add Student");
        addButton.addActionListener(new AddStudentListener());
        addButton.setBackground(green);
        inputPanel.add(addButton);
        
        JButton exit = new JButton("EXIT");
        exit.addActionListener(new ShowExit());
        exit.setBackground(red);
        inputPanel.add(exit);

        JButton avgButton = new JButton("Show Average Marks");
        avgButton.addActionListener(new ShowAverageListener());
        inputPanel.add(avgButton);

        // Create table
        String[] columnNames = {"Name", "Reg Number", "Average"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Add components to the frame
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    private class AddStudentListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String name = nameField.getText();
                String regNumber = regNumberField.getText();
                int mathMarks = Integer.parseInt(mathMarksField.getText());
                int javaMarks = Integer.parseInt(javaMarksField.getText());
                int phpMarks = Integer.parseInt(phpMarksField.getText());

                if (name.isEmpty() || !Pattern.matches("[a-zA-Z\\s]+", name)) {
                    throw new IllegalArgumentException("Name must be a non-empty string containing only letters and spaces.");
                }
                if (regNumber.isEmpty() || regNumber.length() > 10) {
                    throw new IllegalArgumentException("Registration Number cannot be empty and must not exceed 10 characters.");
                }
                if (mathMarks < 0 || mathMarks > 100 || javaMarks < 0 || javaMarks > 100 || phpMarks < 0 || phpMarks > 100) {
                    throw new IllegalArgumentException("Marks must be between 0 and 100.");
                }

                Student student = new Student(name, regNumber, mathMarks, javaMarks, phpMarks);
                students.add(student);

                tableModel.addRow(new Object[]{name, regNumber, mathMarks, javaMarks, phpMarks, student.getAverageMarks()});

                // Highlight the top student
                highlightTopStudent();

                // Clear input fields
                nameField.setText("");
                regNumberField.setText("");
                mathMarksField.setText("");
                javaMarksField.setText("");
                phpMarksField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(StudentManagementSystem.this, "Invalid input. Please enter numeric values for marks.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(StudentManagementSystem.this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void highlightTopStudent() {
        int rowCount = tableModel.getRowCount();
        if (rowCount == 0) {
            return;
        }

        int topStudentRow = 0;
        double highestAverage = (double) tableModel.getValueAt(0, 5);

        for (int i = 1; i < rowCount; i++) {
            double average = (double) tableModel.getValueAt(i, 5);
            if (average > highestAverage) {
                highestAverage = average;
                topStudentRow = i;
            }
        }

        table.clearSelection();
        table.setRowSelectionInterval(topStudentRow, topStudentRow);
        table.scrollRectToVisible(table.getCellRect(topStudentRow, 0, true));
    }

    private class ShowAverageListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (students.isEmpty()) {
                JOptionPane.showMessageDialog(StudentManagementSystem.this, "No students to calculate average.", "Information", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            double total = 0;
            for (Student student : students) {
                total += student.getAverageMarks();
            }
            double average = total / students.size();
            JOptionPane.showMessageDialog(StudentManagementSystem.this, "Average marks of all students: " + average, "Average Marks", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private class ShowExit implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
         Scanner scann=new Scanner(System.in);
    
    Connection conn=null;
    Statement st=null;
    
        SwingUtilities.invokeLater(() -> {
            StudentManagementSystem frame = new StudentManagementSystem();
            frame.setVisible(true);
        });
    }
}
